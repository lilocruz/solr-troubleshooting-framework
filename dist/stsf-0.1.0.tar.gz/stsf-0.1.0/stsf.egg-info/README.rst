This package is a side project that i'm working on with the aim of learning more Python programming. Also it will serve as an starting point for troubleshooting Apache Solr Installations.

INSTALL:

pip install stsf

REQUERIMENTS:

requests
