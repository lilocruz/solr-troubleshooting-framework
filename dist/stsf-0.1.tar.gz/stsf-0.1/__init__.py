"""
stsf.

A Python module for troubleshooting Apache Solr installations.
"""

__version__ = "0.1"
__author__ = 'Michael Sanchez'
__credits__ = 'Michael Sanchez Search Engineer @lucidworks'
